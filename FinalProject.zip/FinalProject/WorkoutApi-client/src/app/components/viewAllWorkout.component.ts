import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';
import {Router} from "@angular/router";

import { WorkoutService } from './service/workout.service';

import {Category} from './model/Category';
import {Workout} from './model/Workout';
import {WorkoutActive} from './model/WorkoutActive';

@Component({
  selector: 'app-root',
  templateUrl: './viewAllWorkout.component.html',
  providers: [ WorkoutService],
  styleUrls: ['./public/css/app.css']
})
export class ViewAllWorkoutComponent implements OnInit {

  error: any;
  workouts:Workout[];
  srchWorkoutTxt:string[];
  
  constructor(private workoutService: WorkoutService,private router: Router) {}
  
  ngOnInit() {		
	this.getAllWorkouts();
  }
  getAllWorkouts(): void {
	  this.workoutService.getAllWorkouts()
      .subscribe(workouts => this.workouts = workouts);
  }
  updateCategory(workout:Workout){
	 console.log("Editing workout:"+workout.workoutTitle);
	 this.router.navigate(['/EditWorkout/'+workout._id]);    
  } 
   
  deleteWorkout(workout:Workout): void {
	console.log("Deleting workout:"+workout._id);	  
	this.workouts = this.workouts.filter(h => h !== workout);
    this.workoutService.deleteWorkout(workout).subscribe();
  }  

  startWorkout(workout:Workout){
	  console.log("Starting workout:"+workout._id);	  
	  this.router.navigate(['/StartWorkout/Start/'+workout._id]); 
  }
  endWorkout(workout:Workout){
	  console.log("Ending workout:"+workout._id);
	  this.router.navigate(['/EndWorkout/End/'+workout._id]); 
  }

}