"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var WorkoutPipe = (function () {
    function WorkoutPipe() {
    }
    WorkoutPipe.prototype.transform = function (items, searchText) {
        console.log("hi***searchText**********" + searchText);
        if (!items)
            return [];
        if (!searchText)
            return items;
        searchText = searchText.toLowerCase();
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return items.filter(function (it) {
            console.log(it.workoutTitle);
            return it.workoutTitle.toLowerCase().includes(searchText);
        });
        //return items.filter(item => item.categoryName.indexOf(searchText) !== -1);
    };
    return WorkoutPipe;
}());
WorkoutPipe = __decorate([
    core_1.Pipe({ name: 'workoutPipe' })
], WorkoutPipe);
exports.WorkoutPipe = WorkoutPipe;
//# sourceMappingURL=workout.pipe.js.map