"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var category_service_1 = require("./service/category.service");
var ConfigComponent = (function () {
    function ConfigComponent(configService) {
        this.configService = configService;
    }
    ConfigComponent.prototype.clear = function () {
        this.config = undefined;
        this.error = undefined;
        this.headers = undefined;
    };
    ConfigComponent.prototype.showConfig = function () {
        var _this = this;
        this.configService.getConfig()
            .subscribe(function (data) { return _this.config = __assign({}, data); }, // success path
        function (// success path
            error) { return _this.error = error; } // error path
        );
    };
    ConfigComponent.prototype.showConfig_v1 = function () {
        var _this = this;
        this.configService.getConfig_1()
            .subscribe(function (data) { return _this.config = {
            heroesUrl: data['heroesUrl'],
            textfile: data['textfile']
        }; });
    };
    ConfigComponent.prototype.showConfig_v2 = function () {
        var _this = this;
        this.configService.getConfig()
            .subscribe(function (data) { return _this.config = __assign({}, data); });
    };
    return ConfigComponent;
}());
ConfigComponent = __decorate([
    core_1.Component({
        selector: 'app-config',
        templateUrl: './category.component.html',
        providers: [category_service_1.CategoryService],
        styleUrls: ['./public/css/app.css']
    }),
    __metadata("design:paramtypes", [category_service_1.CategoryService])
], ConfigComponent);
exports.ConfigComponent = ConfigComponent;
//# sourceMappingURL=config.component.js.map