"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var chart_data_1 = require("./chart-data");
var Chart = require("chart.js");
var COLORS = ['#33FFF3', '#FFE633', '#3339FF', '#FF7133', '#5FBA6A', '#94CFF8', '#1B1D92'];
var TrackWorkoutComponent = (function () {
    function TrackWorkoutComponent() {
    }
    TrackWorkoutComponent.prototype.ngAfterViewInit = function () {
        var barColors = [];
        this.chartData.labels.forEach(function (label, index) {
            barColors.push(COLORS[index % COLORS.length]);
        });
        this.canvas = document.getElementById(this.chartData.id);
        this.ctx = this.canvas.getContext('2d');
        var myChart = new Chart(this.ctx, {
            type: 'bar',
            data: {
                labels: this.chartData.labels,
                datasets: [{
                        label: this.chartData.label,
                        data: this.chartData.data,
                        borderWidth: 1,
                        backgroundColor: barColors
                    }]
            },
            options: {
                responsive: false,
                display: true,
                legend: {
                    labels: {
                        fontColor: "#000",
                        fontSize: 18
                    }
                },
                scales: {
                    yAxes: [{
                            ticks: {
                                fontColor: "#000",
                                beginAtZero: true
                            },
                            gridLines: {
                                color: "#000",
                            }
                        }],
                    xAxes: [{
                            ticks: {
                                fontColor: "#000",
                            },
                            gridLines: {
                                color: "#000",
                            }
                        }]
                }
            }
        });
    };
    return TrackWorkoutComponent;
}());
__decorate([
    core_1.Input('chartData'),
    __metadata("design:type", typeof (_a = typeof chart_data_1.ChartData !== "undefined" && chart_data_1.ChartData) === "function" && _a || Object)
], TrackWorkoutComponent.prototype, "chartData", void 0);
TrackWorkoutComponent = __decorate([
    core_1.Component({
        selector: 'TrackWorkoutComponent',
        templateUrl: './track.component.html',
        styleUrls: ['./public/css/app.css']
    }),
    __metadata("design:paramtypes", [])
], TrackWorkoutComponent);
exports.TrackWorkoutComponent = TrackWorkoutComponent;
var _a;
//# sourceMappingURL=barChart.component.js.map