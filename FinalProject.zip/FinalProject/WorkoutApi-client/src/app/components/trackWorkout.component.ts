import { Component, Input, AfterViewInit } from '@angular/core'; 
 
@Component({
  selector: 'my-app',
  templateUrl: './track.component.html',
  styleUrls: ['./public/css/app.css']
})

export class TrackWorkoutComponent {		
	workoutTimeOfDay:number=41;
	workoutTimeOfWeek:number=246;
	workoutTimeOfMonth:number=1095;

	public barChartOptions1:any = {
                responsive: false,
                display: true,
                legend: {
                    labels: {
                        fontColor: "#000",
                        fontSize: 18
                    }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            fontColor: "#000",
                            beginAtZero: true
                        },
                         gridLines: {
                            color: "#000",
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            fontColor: "#000",
                        },
                        gridLines: {
                            color: "#000",
                        }
                    }]
                }
            }
			
  public barChartOptions:any = {
		scaleShowVerticalLines: false,
		responsive: true
  };
  public barChartLabels:string[] = ['Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat', 'Sun'];
  public barChartType:string = 'bar';
  public barChartLegend:boolean = true;
 
  public barChartData:any[] = [
	{data: [500,400,600,300,700,355,840], label: 'Calories Burnt'}	
  ];
 
  // events
  public chartClicked(e:any):void {
	console.log(e);
  }
 
  public chartHovered(e:any):void {
	console.log(e);
  }
  
}